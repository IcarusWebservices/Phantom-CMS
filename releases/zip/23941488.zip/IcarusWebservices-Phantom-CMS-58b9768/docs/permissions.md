# Permissions Number
Each binary didgit represents a permission, either 1 (allowed / true) or 0 (not allowed / false).

## List of didgets. (Index is from right to left)

| Didget Index | Flag name | Description |
|--------------|-----------|-------------|
| 0 | `is_administrator` | If this flag is set, it means that the user has all other permissions | 
