const banner = document.querySelector('.banner');
const navbar = document.querySelector('.navbar');

if (banner) {
  navbar.classList.add('transparent');
}
