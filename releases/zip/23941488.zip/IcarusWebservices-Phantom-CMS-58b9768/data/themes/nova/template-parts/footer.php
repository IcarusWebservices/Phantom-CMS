<footer>
    <p>© Icarus Webservices, <?= date("Y") ?>. All rights reserved.</p>
</footer>